function o(n,t){const{transition:r,params:i,enabled:a}=t;return a?r(n,i):"duration"in i?r(n,{duration:0}):{duration:0}}export{o as d};
