import{c as m,a as i}from"./CtfeAAbw.js";import{f as n}from"./B4GrenNm.js";import{s as p}from"./BWMYve5J.js";function c(a,o){var r=m(),t=n(r);p(t,()=>o.children),i(a,r)}export{c as L};
