import{i,E as o,x as f,F as p,G as c,j as d,z as h}from"./B4GrenNm.js";function _(e,n,...t){var s=e,r=p,a;i(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=f(()=>r(s,...t)))},o),d&&(s=h)}export{_ as s};
