import"./Bzak7iHL.js";import{e,a as i,b as m}from"./pV5yBOfK.js";import{s as n}from"./CPDBQclr.js";function c(r,o){var a=e(),t=i(a);n(t,()=>o.children),m(r,a)}export{c as L};
