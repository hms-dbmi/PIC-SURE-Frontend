import{c as m,a as i}from"./DKNWTM-D.js";import{f as n}from"./KPVYLOSR.js";import{s as p}from"./kg2g7Go4.js";function c(a,o){var r=m(),t=n(r);p(t,()=>o.children),i(a,r)}export{c as L};
