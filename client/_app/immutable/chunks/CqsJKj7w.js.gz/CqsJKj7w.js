import"./Bzak7iHL.js";import{e,a as i,b as m}from"./DhSNEPDw.js";import{s as n}from"./C8tG8t5X.js";function c(r,o){var a=e(),t=i(a);n(t,()=>o.children),m(r,a)}export{c as L};
