function i(r){if(r==="")return[];try{return JSON.parse(r)}catch{return console.error("Error parsing JSON required fields object."),[]}}export{i as p};
