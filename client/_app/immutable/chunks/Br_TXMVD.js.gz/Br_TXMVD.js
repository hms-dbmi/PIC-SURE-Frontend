import{w as a}from"./DA0IzwqI.js";const p=a(!1);export{p};
