import{at as n,au as s}from"./DhSNEPDw.js";function x(e){const t=Symbol();return[o=>n(t,o),()=>s(t)??e,t]}export{x as c};
