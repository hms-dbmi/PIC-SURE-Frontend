import{ar as s,as as n}from"./pV5yBOfK.js";function x(e){const t=Symbol();return[o=>s(t,o),()=>n(t)??e,t]}export{x as c};
