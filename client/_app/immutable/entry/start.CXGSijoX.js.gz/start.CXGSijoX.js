import{l as o,a as r}from"../chunks/BPde4ukL.js";export{o as load_css,r as start};
