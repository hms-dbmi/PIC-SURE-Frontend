import{c as a}from"../chunks/ClzUMQ0P.js";export{a as start};
