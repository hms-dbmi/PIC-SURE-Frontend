import{c as a}from"../chunks/BMKj-mzl.js";export{a as start};
