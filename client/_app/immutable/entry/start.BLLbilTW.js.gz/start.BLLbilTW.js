import{c as a}from"../chunks/D9QhBFw8.js";export{a as start};
