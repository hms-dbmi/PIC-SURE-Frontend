import{c as a}from"../chunks/Dx2jxSvH.js";export{a as start};
