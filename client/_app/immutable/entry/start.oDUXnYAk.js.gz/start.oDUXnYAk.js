import{c as a}from"../chunks/zOfZnRfh.js";export{a as start};
