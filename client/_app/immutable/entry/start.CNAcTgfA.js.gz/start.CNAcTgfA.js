import{l as o,c as r}from"../chunks/DNfOBMJV.js";export{o as load_css,r as start};
